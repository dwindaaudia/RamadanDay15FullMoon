﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace THW5_Appdev
{
    public partial class Form1 : Form
    {

        DataTable dtProductSimpan = new DataTable();
        DataTable dtProductTampil = new DataTable();
        DataTable dtCategorySimpan = new DataTable();
        DataTable dtCategoryTampil = new DataTable();
        DataColumn column = new DataColumn();
        DataRow row;

        List<string> listIDProduct = new List<string> { "J001", "T001", "T002", "R001", "J002", "C001", "C002", "R002" };
        List<string> listNamaProduct = new List<string> { "Jas Hitam", "T-Shirt Black Pink", "T-Shirt Obsessive", "Rok mini", "Jeans Biru", "Celana Pendek Coklat", "Cawat Blink-blink", "Rocca Shirt" };
        List<int> listHargaProduct = new List<int> { 100000, 70000, 75000, 82000, 90000, 60000, 1000000, 50000 };
        List<int> listStockProduct = new List<int> { 10, 20, 16, 26, 5, 11, 1, 8 };
        List<string> listProduct_IDCategory = new List<string> { "C1", "C2", "C2", "C3", "C4", "C4", "C5", "C2" };
        List<string> listIDCategory = new List<string> { "C1", "C2", "C3", "C4", "C5" };
        List<string> listNamaCategory = new List<string> { "Jas", "T-Shirt", "Rok", "Celana", "Cawat" };

        string passCat = "";
        string passID = "";

        public Form1()
        {
            InitializeComponent();
            textBox_namaProduct.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox_filter.Enabled = false;
            column = new DataColumn();
            column.ColumnName = "ID Product";
            dtProductSimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Nama Product";
            dtProductSimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Harga";
            dtProductSimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Stock";
            dtProductSimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "ID Category";
            dtProductSimpan.Columns.Add(column);
            for (int i = 0; i < listIDProduct.Count; i++)
            {
                row = dtProductSimpan.NewRow();
                row[0] = listIDProduct[i];
                row[1] = listNamaProduct[i];
                row[2] = listHargaProduct[i];
                row[3] = listStockProduct[i];
                row[4] = listProduct_IDCategory[i];
                dtProductSimpan.Rows.Add(row);
            }
            column = new DataColumn();
            column.ColumnName = "ID Category";
            dtCategorySimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Nama Category";
            dtCategorySimpan.Columns.Add(column);
            for (int j = 0; j < listIDCategory.Count; j++)
            {
                row = dtCategorySimpan.NewRow();
                row[0] = listIDCategory[j];
                row[1] = listNamaCategory[j];
                dtCategorySimpan.Rows.Add(row);
            }
            dtProductTampil = dtProductSimpan.Copy();
            dataGridView_product.DataSource = dtProductTampil;
            dataGridView_category.DataSource = dtCategorySimpan;
            comboBox_filter.DataSource = dtCategorySimpan.Copy();
            comboBox_filter.DisplayMember = "Nama Category";
            comboBox_filter.ValueMember = "ID Category";
            comboBox_category.DataSource = dtCategorySimpan.Copy();
            comboBox_category.DisplayMember = "Nama Category";
            comboBox_category.ValueMember = "ID Category";
            comboBox_filter.Text = "";
            dataGridView_product.Columns[1].Width = 100;
            dataGridView_product.Columns["Stock"].Width = 50;

            btn_all.Focus();
            textBox_namaProduct.Focus();
            dataGridView_category.CurrentCell = null;
            dataGridView_product.ClearSelection();
            dataGridView_product.CurrentCell = null;
            comboBox_category.Text = "";


        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            comboBox_filter.Enabled = true;
        }

        public void Filter (string nilai)
        {
            if (nilai != "")
            {
                dtProductTampil.Rows.Clear();
                for (int i = 0; i < dtProductSimpan.Rows.Count; i++)
                {
                    if (dtProductSimpan.Rows[i][4].ToString() == nilai)
                    {
                        row = dtProductTampil.NewRow();
                        row[0] = dtProductSimpan.Rows[i][0];
                        row[1] = dtProductSimpan.Rows[i][1];
                        row[2] = dtProductSimpan.Rows[i][2];
                        row[3] = dtProductSimpan.Rows[i][3];
                        row[4] = dtProductSimpan.Rows[i][4];
                        dtProductTampil.Rows.Add(row);
                    }
                }
            }
            else
            {
                dtProductTampil.Rows.Clear();
                for (int j = 0; j < dtProductSimpan.Rows.Count; j++)
                {
                    row = dtProductTampil.NewRow();
                    row[0] = dtProductSimpan.Rows[j][0];
                    row[1] = dtProductSimpan.Rows[j][1];
                    row[2] = dtProductSimpan.Rows[j][2];
                    row[3] = dtProductSimpan.Rows[j][3];
                    row[4] = dtProductSimpan.Rows[j][4];
                    dtProductTampil.Rows.Add(row);
                }
            }
            dataGridView_product.CurrentCell = null;
            dataGridView_category.CurrentCell = null;
            (textBox_namaProduct).Clear();
            (textBox_harga).Clear();
            (textBox_stock).Clear();
            passID = "";
            passCat = "";
            comboBox_category.DataSource = dtCategorySimpan.Copy();
            comboBox_filter.DataSource = dtCategorySimpan.Copy();
            (comboBox_category).Text = "";
            (comboBox_filter).Text = "";
            (textBox_category).Text = "";
        }

        private void comboBox_filter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Filter(comboBox_filter.SelectedValue.ToString());
        }       

        private void addProduct()
        {
            if (textBox_namaProduct.Text == "" || textBox_harga.Text == "" || textBox_stock.Text == "")
            {
                MessageBox.Show("Input tidak lengkap");
                return;
            }
            if (comboBox_category.SelectedValue == null || comboBox_category.Text == "")
            {
                MessageBox.Show("Pilih Category terlebih dahulu");
                return;
            }
            string text = textBox_namaProduct.Text[0].ToString().ToUpper();
            int num = 0;
            foreach (DataRow row in dtProductSimpan.Rows)
            {
                if (row[0].ToString()[0].ToString() == text)
                {
                    int num2 = Convert.ToInt32(row[0].ToString().Substring(1));
                    if (num <= num2)
                    {
                        num = num2;
                    }
                }
            }
            num++;
            string text2 = text.ToString();
            for (int i = num.ToString().Length; i < 3; i++)
            {
                text2 += "0";
            }
            text2 += num;
            this.row = dtProductSimpan.NewRow();
            this.row[0] = text2;
            this.row[1] = textBox_namaProduct.Text;
            this.row[2] = textBox_harga.Text;
            this.row[3] = textBox_stock.Text;
            this.row[4] = comboBox_category.SelectedValue;
            dtProductSimpan.Rows.Add(this.row);
            Filter("");
        }
        private void button_addProduct_Click(object sender, EventArgs e)
        {
            addProduct();
        }

        private void dataGridView_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                passID = dataGridView_product.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox_namaProduct.Text = dataGridView_product.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox_harga.Text = dataGridView_product.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox_stock.Text = dataGridView_product.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox_stock.Text = dataGridView_product.Rows[e.RowIndex].Cells[3].Value.ToString();
                comboBox_category.SelectedValue = dataGridView_product.Rows[e.RowIndex].Cells[4].Value.ToString();
                if (!(comboBox_category.Text == ""))
                {
                    return;
                }
                foreach (DataRow row in dtCategorySimpan.Rows)
                {
                    if (row[0].ToString() == dataGridView_product.Rows[e.RowIndex].Cells[4].Value.ToString())
                    {
                        comboBox_category.Text = row[1].ToString();
                    }
                }
            }
            catch (Exception)
            {
                dataGridView_product.CurrentCell = null;
            }
        }

        private void button_editProduct_Click(object sender, EventArgs e)
        {
            if (passID != "")
            {
                if(textBox_namaProduct.Text == "" || textBox_harga.Text == "" || textBox_stock.Text == "")
                {
                    MessageBox.Show("Error");
                }
                else if (comboBox_category.SelectedValue == null || comboBox_category.Text == "")
                {
                    MessageBox.Show("Error");
                }
                else
                {
                    foreach (DataRow row in dtProductSimpan.Rows)
                    {
                        if (row[0].ToString() == passID)
                        {
                            row[1] = textBox_namaProduct.Text;
                            row[2] = textBox_harga.Text;
                            row[3] = textBox_stock.Text;
                            row[4] = comboBox_category.SelectedValue;
                            if (row[3].ToString() == "0")
                            {
                                dtProductSimpan.Rows.Remove(row);
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Pilih produk yang akan diedit terlebih dahulu");
            }
            Filter("");
        }

        private void button_removeProduct_Click(object sender, EventArgs e)
        {
            foreach (DataRow row in dtProductSimpan.Rows )
            {
                if (row[0].ToString() == passID)
                {
                    dtProductSimpan.Rows.Remove(row);
                    break;
                }
            }
            Filter("");
        }

        private void button_addCategory_Click(object sender, EventArgs e)
        {
            if (textBox_category.Text == "")
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu", "Hadee");
                return;
            }
            bool flag = true;
            foreach (DataRow row in dtCategorySimpan.Rows )
            {
                if (textBox_category.Text == row[1].ToString())
                {
                    flag = false;
                }
            }
            if (!flag)
            {
                MessageBox.Show("Category sudah ada", "Ga bisa");
                return;
            }
            int num = 0;
            foreach (DataRow row2 in dtCategorySimpan.Rows )
            {
                int num2 = Convert.ToInt32(row2[0].ToString().Substring(1));
                if (num <= num2)
                {
                    num = num2;
                }
            }
            string text = "C";
            text += num + 1;
            this.row = dtCategorySimpan.NewRow();
            this.row[0] = text;
            this.row[1] = textBox_category.Text;
            dtCategorySimpan.Rows.Add(this.row);
            Filter("");
        }

        private void button_removeCategory_Click(object sender, EventArgs e)
        {
            
            foreach (DataRow row in dtCategorySimpan.Rows)
            {
                if (row[0].ToString() == passCat)
                {
                    dtCategorySimpan.Rows.Remove(row);
                    break;
                }
            }
            for (int num = dtProductSimpan.Rows.Count - 1; num >= 0; num--)
            {
                if (dtProductSimpan.Rows[num]["ID Category"].ToString() == passCat)
                {
                    dtProductSimpan.Rows.Remove(dtProductSimpan.Rows[num]);

                }
            }
            Filter("");
        }

        private void textBox_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            comboBox_filter.Enabled = false;
            Filter("");
            dataGridView_category.CurrentCell = null;
            dataGridView_product.CurrentCell = null;
        }

        private void dataGridView_category_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                passCat = dataGridView_category.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox_category.Text = dataGridView_category.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
            catch (Exception)
            {
                dataGridView_category.CurrentCell = null;
            }
        }
    }
}
