﻿namespace THW5_Appdev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_judul = new System.Windows.Forms.Label();
            this.label_category = new System.Windows.Forms.Label();
            this.label_details = new System.Windows.Forms.Label();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.comboBox_filter = new System.Windows.Forms.ComboBox();
            this.dataGridView_product = new System.Windows.Forms.DataGridView();
            this.dataGridView_category = new System.Windows.Forms.DataGridView();
            this.label_nama = new System.Windows.Forms.Label();
            this.label_categoryd = new System.Windows.Forms.Label();
            this.label_harga = new System.Windows.Forms.Label();
            this.label_stock = new System.Windows.Forms.Label();
            this.textBox_namaProduct = new System.Windows.Forms.TextBox();
            this.comboBox_category = new System.Windows.Forms.ComboBox();
            this.textBox_harga = new System.Windows.Forms.TextBox();
            this.textBox_stock = new System.Windows.Forms.TextBox();
            this.button_addProduct = new System.Windows.Forms.Button();
            this.button_editProduct = new System.Windows.Forms.Button();
            this.button_removeProduct = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_category = new System.Windows.Forms.TextBox();
            this.button_addCategory = new System.Windows.Forms.Button();
            this.button_removeCategory = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_judul
            // 
            this.lb_judul.AutoSize = true;
            this.lb_judul.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_judul.Location = new System.Drawing.Point(32, 35);
            this.lb_judul.Name = "lb_judul";
            this.lb_judul.Size = new System.Drawing.Size(119, 32);
            this.lb_judul.TabIndex = 0;
            this.lb_judul.Text = "Product";
            // 
            // label_category
            // 
            this.label_category.AutoSize = true;
            this.label_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_category.Location = new System.Drawing.Point(674, 35);
            this.label_category.Name = "label_category";
            this.label_category.Size = new System.Drawing.Size(137, 32);
            this.label_category.TabIndex = 1;
            this.label_category.Text = "Category";
            // 
            // label_details
            // 
            this.label_details.AutoSize = true;
            this.label_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_details.Location = new System.Drawing.Point(32, 403);
            this.label_details.Name = "label_details";
            this.label_details.Size = new System.Drawing.Size(109, 32);
            this.label_details.TabIndex = 2;
            this.label_details.Text = "Details";
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(293, 46);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(75, 31);
            this.btn_all.TabIndex = 3;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(374, 46);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(75, 31);
            this.btn_filter.TabIndex = 4;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // comboBox_filter
            // 
            this.comboBox_filter.FormattingEnabled = true;
            this.comboBox_filter.Location = new System.Drawing.Point(455, 48);
            this.comboBox_filter.Name = "comboBox_filter";
            this.comboBox_filter.Size = new System.Drawing.Size(179, 28);
            this.comboBox_filter.TabIndex = 5;
            this.comboBox_filter.SelectionChangeCommitted += new System.EventHandler(this.comboBox_filter_SelectionChangeCommitted);
            // 
            // dataGridView_product
            // 
            this.dataGridView_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_product.Location = new System.Drawing.Point(38, 105);
            this.dataGridView_product.Name = "dataGridView_product";
            this.dataGridView_product.RowHeadersWidth = 62;
            this.dataGridView_product.RowTemplate.Height = 28;
            this.dataGridView_product.Size = new System.Drawing.Size(596, 274);
            this.dataGridView_product.TabIndex = 6;
            this.dataGridView_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_product_CellClick);
            // 
            // dataGridView_category
            // 
            this.dataGridView_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_category.Location = new System.Drawing.Point(680, 105);
            this.dataGridView_category.Name = "dataGridView_category";
            this.dataGridView_category.RowHeadersWidth = 62;
            this.dataGridView_category.RowTemplate.Height = 28;
            this.dataGridView_category.Size = new System.Drawing.Size(404, 237);
            this.dataGridView_category.TabIndex = 7;
            this.dataGridView_category.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_category_CellMouseClick);
            // 
            // label_nama
            // 
            this.label_nama.AutoSize = true;
            this.label_nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nama.Location = new System.Drawing.Point(33, 458);
            this.label_nama.Name = "label_nama";
            this.label_nama.Size = new System.Drawing.Size(80, 25);
            this.label_nama.TabIndex = 8;
            this.label_nama.Text = "Nama : ";
            // 
            // label_categoryd
            // 
            this.label_categoryd.AutoSize = true;
            this.label_categoryd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_categoryd.Location = new System.Drawing.Point(33, 495);
            this.label_categoryd.Name = "label_categoryd";
            this.label_categoryd.Size = new System.Drawing.Size(108, 25);
            this.label_categoryd.TabIndex = 9;
            this.label_categoryd.Text = "Category : ";
            // 
            // label_harga
            // 
            this.label_harga.AutoSize = true;
            this.label_harga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_harga.Location = new System.Drawing.Point(33, 535);
            this.label_harga.Name = "label_harga";
            this.label_harga.Size = new System.Drawing.Size(81, 25);
            this.label_harga.TabIndex = 10;
            this.label_harga.Text = "Harga : ";
            // 
            // label_stock
            // 
            this.label_stock.AutoSize = true;
            this.label_stock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_stock.Location = new System.Drawing.Point(33, 574);
            this.label_stock.Name = "label_stock";
            this.label_stock.Size = new System.Drawing.Size(78, 25);
            this.label_stock.TabIndex = 11;
            this.label_stock.Text = "Stock : ";
            // 
            // textBox_namaProduct
            // 
            this.textBox_namaProduct.Location = new System.Drawing.Point(149, 457);
            this.textBox_namaProduct.Name = "textBox_namaProduct";
            this.textBox_namaProduct.Size = new System.Drawing.Size(485, 26);
            this.textBox_namaProduct.TabIndex = 12;
            // 
            // comboBox_category
            // 
            this.comboBox_category.FormattingEnabled = true;
            this.comboBox_category.Location = new System.Drawing.Point(149, 496);
            this.comboBox_category.Name = "comboBox_category";
            this.comboBox_category.Size = new System.Drawing.Size(167, 28);
            this.comboBox_category.TabIndex = 13;
            // 
            // textBox_harga
            // 
            this.textBox_harga.Location = new System.Drawing.Point(149, 536);
            this.textBox_harga.Name = "textBox_harga";
            this.textBox_harga.Size = new System.Drawing.Size(167, 26);
            this.textBox_harga.TabIndex = 14;
            this.textBox_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_harga_KeyPress);
            // 
            // textBox_stock
            // 
            this.textBox_stock.Location = new System.Drawing.Point(149, 575);
            this.textBox_stock.Name = "textBox_stock";
            this.textBox_stock.Size = new System.Drawing.Size(167, 26);
            this.textBox_stock.TabIndex = 15;
            this.textBox_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_stock_KeyPress);
            // 
            // button_addProduct
            // 
            this.button_addProduct.Location = new System.Drawing.Point(348, 526);
            this.button_addProduct.Name = "button_addProduct";
            this.button_addProduct.Size = new System.Drawing.Size(88, 66);
            this.button_addProduct.TabIndex = 16;
            this.button_addProduct.Text = "Add Product";
            this.button_addProduct.UseVisualStyleBackColor = true;
            this.button_addProduct.Click += new System.EventHandler(this.button_addProduct_Click);
            // 
            // button_editProduct
            // 
            this.button_editProduct.Location = new System.Drawing.Point(443, 526);
            this.button_editProduct.Name = "button_editProduct";
            this.button_editProduct.Size = new System.Drawing.Size(88, 67);
            this.button_editProduct.TabIndex = 17;
            this.button_editProduct.Text = "Edit Product";
            this.button_editProduct.UseVisualStyleBackColor = true;
            this.button_editProduct.Click += new System.EventHandler(this.button_editProduct_Click);
            // 
            // button_removeProduct
            // 
            this.button_removeProduct.Location = new System.Drawing.Point(538, 526);
            this.button_removeProduct.Name = "button_removeProduct";
            this.button_removeProduct.Size = new System.Drawing.Size(88, 67);
            this.button_removeProduct.TabIndex = 18;
            this.button_removeProduct.Text = "Remove Product";
            this.button_removeProduct.UseVisualStyleBackColor = true;
            this.button_removeProduct.Click += new System.EventHandler(this.button_removeProduct_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(675, 376);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 25);
            this.label1.TabIndex = 19;
            this.label1.Text = "Nama : ";
            // 
            // textBox_category
            // 
            this.textBox_category.Location = new System.Drawing.Point(761, 377);
            this.textBox_category.Name = "textBox_category";
            this.textBox_category.Size = new System.Drawing.Size(323, 26);
            this.textBox_category.TabIndex = 20;
            // 
            // button_addCategory
            // 
            this.button_addCategory.Location = new System.Drawing.Point(830, 431);
            this.button_addCategory.Name = "button_addCategory";
            this.button_addCategory.Size = new System.Drawing.Size(88, 66);
            this.button_addCategory.TabIndex = 21;
            this.button_addCategory.Text = "Add Category";
            this.button_addCategory.UseVisualStyleBackColor = true;
            this.button_addCategory.Click += new System.EventHandler(this.button_addCategory_Click);
            // 
            // button_removeCategory
            // 
            this.button_removeCategory.Location = new System.Drawing.Point(924, 431);
            this.button_removeCategory.Name = "button_removeCategory";
            this.button_removeCategory.Size = new System.Drawing.Size(88, 67);
            this.button_removeCategory.TabIndex = 22;
            this.button_removeCategory.Text = "Remove Category";
            this.button_removeCategory.UseVisualStyleBackColor = true;
            this.button_removeCategory.Click += new System.EventHandler(this.button_removeCategory_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 658);
            this.Controls.Add(this.button_removeCategory);
            this.Controls.Add(this.button_addCategory);
            this.Controls.Add(this.textBox_category);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_removeProduct);
            this.Controls.Add(this.button_editProduct);
            this.Controls.Add(this.button_addProduct);
            this.Controls.Add(this.textBox_stock);
            this.Controls.Add(this.textBox_harga);
            this.Controls.Add(this.comboBox_category);
            this.Controls.Add(this.textBox_namaProduct);
            this.Controls.Add(this.label_stock);
            this.Controls.Add(this.label_harga);
            this.Controls.Add(this.label_categoryd);
            this.Controls.Add(this.label_nama);
            this.Controls.Add(this.dataGridView_category);
            this.Controls.Add(this.dataGridView_product);
            this.Controls.Add(this.comboBox_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.label_details);
            this.Controls.Add(this.label_category);
            this.Controls.Add(this.lb_judul);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_judul;
        private System.Windows.Forms.Label label_category;
        private System.Windows.Forms.Label label_details;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox comboBox_filter;
        private System.Windows.Forms.DataGridView dataGridView_product;
        private System.Windows.Forms.DataGridView dataGridView_category;
        private System.Windows.Forms.Label label_nama;
        private System.Windows.Forms.Label label_categoryd;
        private System.Windows.Forms.Label label_harga;
        private System.Windows.Forms.Label label_stock;
        private System.Windows.Forms.TextBox textBox_namaProduct;
        private System.Windows.Forms.ComboBox comboBox_category;
        private System.Windows.Forms.TextBox textBox_harga;
        private System.Windows.Forms.TextBox textBox_stock;
        private System.Windows.Forms.Button button_addProduct;
        private System.Windows.Forms.Button button_editProduct;
        private System.Windows.Forms.Button button_removeProduct;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_category;
        private System.Windows.Forms.Button button_addCategory;
        private System.Windows.Forms.Button button_removeCategory;
    }
}

